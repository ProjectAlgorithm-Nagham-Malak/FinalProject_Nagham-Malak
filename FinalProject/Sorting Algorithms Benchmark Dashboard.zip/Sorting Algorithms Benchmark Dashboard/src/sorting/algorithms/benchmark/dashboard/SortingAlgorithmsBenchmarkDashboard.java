
package sorting.algorithms.benchmark.dashboard;
/**
 *
 * @author Nagham Debei
 */
public class SortingAlgorithmsBenchmarkDashboard
{
    public static void main(String[] args)
    {
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        System.out.println(" SORTING ALGORITHMS BENCHMARK DASHBOARD ");
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\n");
        SortingAlgorithms.runSortingBenchmark();
        System.out.println("\n<< * BENCHMARK EXECUTED SUCCESSFULLY * >>");
    }    
}
    


    
    

