package sorting.algorithms.benchmark.dashboard;
public class SortingAlgorithmsBenchmarkDashboard
{
    public static void main(String[] args)
    {
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        System.out.println(" SORTING ALGORITHMS BENCHMARK DASHBOARD ");
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\n");
        SortingAlgorithms.SortingBenchmark();
        System.out.println("\n<< * BENCHMARK EXECUTED SUCCESSFULLY * >>");
    }    
}
    


    
    

